#ifndef NOMBRE_H
#define NOMBRE_H

bool par_impar(int n);
bool grande(int n);
bool positivo(int n);
bool divisible5(int n);

#endif
